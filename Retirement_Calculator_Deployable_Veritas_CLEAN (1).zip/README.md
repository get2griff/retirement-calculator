
# Retirement Calculator

This is a deployable Vite + React app for retirement forecasting.
