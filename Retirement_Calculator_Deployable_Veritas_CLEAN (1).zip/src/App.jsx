
import React from 'react';

const App = () => {
  return (
    <div>
      <h1>Retirement Calculator</h1>
      <p>This is your retirement forecasting tool.</p>
    </div>
  );
};

export default App;
